import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-person-two',
  templateUrl: 'person-two.html'
})
export class PersonTwoPage {

  constructor(public navCtrl: NavController) {
  }
  
}
