import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-person-one',
  templateUrl: 'person-one.html'
})
export class PersonOnePage {

  constructor(public navCtrl: NavController) {
  }
  
}
